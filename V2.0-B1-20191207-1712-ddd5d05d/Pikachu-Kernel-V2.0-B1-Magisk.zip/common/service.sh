#!/system/bin/sh

# Copyright (c) 2019 Yuhan Pikachu Technology Lab
# All Rights Reserved.
# Confidential and Proprietary - Pikachu Technology Lab

# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}

# Kang from yc
lock_val() 
{
    if [ -f $2 ]; then
        chmod 0666 $2
        echo $1 > $2
        chmod 0444 $2
    fi
}

# $1:value $2:file path
mutate() 
{
    if [ -f $2 ]; then
        chmod 0666 $2
        echo $1 > $2
    fi
}

# $1:task_name $2:cgroup_name $3:"cpuset"/"stune"
change_task_cgroup()
{
    temp_pids=`ps -Ao pid,cmd | grep "$1" | awk '{print $1}'`
    for temp_pid in $temp_pids
    do
        for temp_tid in `ls /proc/$temp_pid/task/`
        do
            echo $temp_tid > /dev/$3/$2/tasks
        done
    done
}

# $1:task_name $2:hex_mask(0x00000003 is CPU0 and CPU1)
change_task_affinity()
{
    temp_pids=`ps -Ao pid,cmd | grep "$1" | awk '{print $1}'`
    for temp_pid in $temp_pids
    do
        for temp_tid in `ls /proc/$temp_pid/task/`
        do
            taskset -p $2 $temp_tid
        done
    done
}

restart_qti_perfd()
{
    stop perf-hal-1-0
    stop perf-hal-2-0
    start perf-hal-1-0
    start perf-hal-2-0
}

# This script will be executed in late_start service mode
sleep 30

## Start Hacking Kernel Profiles
echo 500 > /sys/devices/system/cpu/cpufreq/policy0/schedutil/up_rate_limit_us
echo 20000 > /sys/devices/system/cpu/cpufreq/policy0/schedutil/down_rate_limit_us

echo 500 > /sys/devices/system/cpu/cpufreq/policy4/schedutil/up_rate_limit_us
echo 20000 > /sys/devices/system/cpu/cpufreq/policy4/schedutil/down_rate_limit_us

echo 500 > /sys/devices/system/cpu/cpufreq/policy7/schedutil/up_rate_limit_us
echo 20000 > /sys/devices/system/cpu/cpufreq/policy7/schedutil/down_rate_limit_us

# save ~100mw under light 3D workload
lock_val "0" /sys/class/kgsl/kgsl-3d0/force_no_nap
lock_val "1" /sys/class/kgsl/kgsl-3d0/bus_split
lock_val "0" /sys/class/kgsl/kgsl-3d0/force_bus_on
lock_val "0" /sys/class/kgsl/kgsl-3d0/force_clk_on
lock_val "0" /sys/class/kgsl/kgsl-3d0/force_rail_on

lock_val 585000000 /sys/class/kgsl/kgsl-3d0/devfreq/max_freq

# yuhan@maintainer, 2019/11/23 modify because we are using cpusets assist and seted on kernel
#echo 0-3 > /dev/cpuset/restricted/cpus
#echo 0-3 > /dev/cpuset/audio-app/cpus
#echo 0-7 > /dev/cpuset/camera-daemon/cpus
#echo 0-7 > /dev/cpuset/top-app/cpus
#echo 0-3,5-6 > /dev/cpuset/foreground/cpus
#echo 0-1 > /dev/cpuset/background/cpus
#echo 0-3 > /dev/cpuset/system-background/cpus

for i in /sys/block/*/queue; do
  echo 0 > $i/iostats;
done;

echo 2000 > /dev/blkio/blkio.group_idle
echo 0 > /dev/blkio/background/blkio.group_idle

echo 1000 > /dev/blkio/blkio.weight
echo 10 > /dev/blkio/background/blkio.weight

echo 1 > /dev/stune/foreground/schedtune.prefer_idle
echo 1 > /dev/stune/top-app/schedtune.prefer_idle
echo 1 > /dev/stune/top-app/schedtune.boost

sysctl -w net.ipv4.tcp_congestion_control=westwood

echo 1382400 > /sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq
echo 1056000 > /sys/devices/system/cpu/cpu4/cpufreq/scaling_min_freq
echo 2323200 > /sys/devices/system/cpu/cpu4/cpufreq/scaling_max_freq
echo 1171200 > /sys/devices/system/cpu/cpu7/cpufreq/scaling_min_freq
echo 2649600 > /sys/devices/system/cpu/cpu7/cpufreq/scaling_max_freq

echo 0 > /proc/sys/vm/page-cluster
echo 10 > /proc/sys/vm/dirty_background_ratio
echo 3000 > /proc/sys/vm/dirty_expire_centisecs

stop vendor.msm_irqbalance
start vendor.msm_irqbalance

setprop persist.sys.ohpd.flags 0
setprop persist.sys.ohpd.kcheck false
setprop persist.vendor.sys.memplus.enable 0

lock_val "0" /dev/stune/background/schedtune.sched_boost_enabled
lock_val "0" /dev/stune/background/schedtune.sched_boost_no_override
lock_val "0" /dev/stune/background/schedtune.boost
lock_val "0" /dev/stune/background/schedtune.prefer_idle
lock_val "0" /dev/stune/foreground/schedtune.sched_boost_enabled
lock_val "0" /dev/stune/foreground/schedtune.sched_boost_no_override
lock_val "0" /dev/stune/foreground/schedtune.boost
lock_val "1" /dev/stune/top-app/schedtune.sched_boost_no_override

# Flash doesn't have back seek problem, so penalty is as low as possible
lock_val "1" /sys/block/sda/queue/iosched/back_seek_penalty
# slice_idle = 0 means CFQ IOP mode, https://lore.kernel.org/patchwork/patch/944972/
lock_val "0" /sys/block/sda/queue/iosched/slice_idle
# UFS 2.0+ hardware queue depth is 32
lock_val "16" /sys/block/sda/queue/iosched/quantum
# lower read_ahead_kb to reduce random access overhead
lock_val "128" /sys/block/sda/queue/read_ahead_kb

# minfree unit(page size): 4K
lock_val "19200,25600,51200,76800,128000,179200" /sys/module/lowmemorykiller/parameters/minfree
lock_val "0,200,920,930,940,950" /sys/module/lowmemorykiller/parameters/adj
# enable automatic kill when vmpressure >= 90
lock_val "1" /sys/module/lowmemorykiller/parameters/enable_adaptive_lmk
# please kill all the processes we really don't want when vmpressure >= 90
lock_val "960" /sys/module/lowmemorykiller/parameters/adj_max_shift
# larger shrinker(LMK) calling interval
lock_val "48" /sys/module/lowmemorykiller/parameters/cost
lock_val "32768" /proc/sys/vm/min_free_kbytes
lock_val "262144" /proc/sys/vm/extra_free_kbytes
# lower to reduce useless page swapping
# scrolling coolapk with the same watermark mid for 8000ms, kswapd took 900ms when wsf=10, took 1200ms when wsf=300
lock_val "20" /proc/sys/vm/watermark_scale_factor

# kernel reclaim thread cannot run on the big cores
change_task_affinity "reclaimd" "0f"
change_task_affinity "oom" "0f"

# treat crtc_commit as display, avoid display preemption on big
lock_val "0-3" /dev/cpuset/display/cpus
change_task_cgroup "crtc_commit" "display" "cpuset"

# fix laggy bilibili feed scrolling
change_task_cgroup "servicemanager" "top-app" "cpuset"
change_task_cgroup "servicemanager" "foreground" "stune"
change_task_cgroup "android.phone" "top-app" "cpuset"
change_task_cgroup "android.phone" "foreground" "stune"

# fix laggy home gesture
change_task_cgroup "system_server" "top-app" "cpuset"
change_task_cgroup "system_server" "top-app" "stune"

# reduce render thread waiting time
change_task_cgroup "surfaceflinger" "top-app" "cpuset"
change_task_cgroup "surfaceflinger" "foreground" "stune"

# avoid swapping of latency intensive processes
mkdir /dev/memcg/lowlat
lock_val "1" /dev/memcg/memory.use_hierarchy
lock_val "1" /dev/memcg/memory.move_charge_at_immigrate
lock_val "1" /dev/memcg/lowlat/memory.move_charge_at_immigrate
lock_val "0" /dev/memcg/lowlat/memory.swappiness

# move latency intensive processes to memcg/lowlat
change_task_cgroup "system_server" "lowlat" "memcg"
change_task_cgroup "surfaceflinger" "lowlat" "memcg"
change_task_cgroup "composer" "lowlat" "memcg"
change_task_cgroup "allocator" "lowlat" "memcg"
change_task_cgroup "systemui" "lowlat" "memcg"

# wait for the launcher to start up
sleep 15
change_task_cgroup "launcher" "lowlat" "memcg"

restart_qti_perfd
## Start Hacking Kernel Profiles
echo 500 > /sys/devices/system/cpu/cpufreq/policy0/schedutil/up_rate_limit_us
echo 20000 > /sys/devices/system/cpu/cpufreq/policy0/schedutil/down_rate_limit_us

echo 500 > /sys/devices/system/cpu/cpufreq/policy4/schedutil/up_rate_limit_us
echo 20000 > /sys/devices/system/cpu/cpufreq/policy4/schedutil/down_rate_limit_us

echo 500 > /sys/devices/system/cpu/cpufreq/policy7/schedutil/up_rate_limit_us
echo 20000 > /sys/devices/system/cpu/cpufreq/policy7/schedutil/down_rate_limit_us

echo 585000000 > /sys/class/kgsl/kgsl-3d0/devfreq/max_freq

# yuhan@maintainer, 2019/11/23 modify because we are using cpusets assist and seted on kernel
#echo 0-3 > /dev/cpuset/restricted/cpus
#echo 0-3 > /dev/cpuset/audio-app/cpus
#echo 0-7 > /dev/cpuset/camera-daemon/cpus
#echo 0-7 > /dev/cpuset/top-app/cpus
#echo 0-3,5-6 > /dev/cpuset/foreground/cpus
#echo 0-1 > /dev/cpuset/background/cpus
#echo 0-3 > /dev/cpuset/system-background/cpus

for i in /sys/block/*/queue; do
  echo 0 > $i/iostats;
done;

echo 2000 > /dev/blkio/blkio.group_idle
echo 0 > /dev/blkio/background/blkio.group_idle

echo 1000 > /dev/blkio/blkio.weight
echo 10 > /dev/blkio/background/blkio.weight

echo 1 > /dev/stune/foreground/schedtune.prefer_idle
echo 1 > /dev/stune/top-app/schedtune.prefer_idle
echo 1 > /dev/stune/top-app/schedtune.boost

sysctl -w net.ipv4.tcp_congestion_control=westwood

echo 1382400 > /sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq
echo 1056000 > /sys/devices/system/cpu/cpu4/cpufreq/scaling_min_freq
echo 2323200 > /sys/devices/system/cpu/cpu4/cpufreq/scaling_max_freq
echo 1171200 > /sys/devices/system/cpu/cpu7/cpufreq/scaling_min_freq
echo 2649600 > /sys/devices/system/cpu/cpu7/cpufreq/scaling_max_freq

echo 0 > /proc/sys/vm/page-cluster
echo 10 > /proc/sys/vm/dirty_background_ratio
echo 3000 > /proc/sys/vm/dirty_expire_centisecs

stop vendor.msm_irqbalance
start vendor.msm_irqbalance

