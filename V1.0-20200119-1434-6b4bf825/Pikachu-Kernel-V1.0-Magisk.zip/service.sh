#!/system/bin/sh

# Pikachu Kernel Profiles Applier
# Copyright (C) 2019 Pikachu Technologies Lab <yuhan@rsyhan.me>

# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in late_start service mode
sleep 30

resetprop ctl.stop oneplus_brain_service
resetprop ctl.stop charger_logkit
resetprop ctl.stop oemlogkit
resetprop ctl.stop opdiagnose
resetprop ctl.stop OPDiagdataCopy

setprop persist.sys.ohpd.flags 0
setprop persist.sys.ohpd.kcheck false
setprop persist.vendor.sys.memplus.enable 0

restart_qti_perfd()
{
    stop perf-hal-1-0
    stop perf-hal-2-0
    start perf-hal-1-0
    start perf-hal-2-0
}

lock_val() {
    if [ -f $2 ]; then
        chmod 0666 $2
        echo $1 > $2
        chmod 0444 $2
    fi
}

echo "schedutil" > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
echo 0 > /sys/devices/system/cpu/cpufreq/policy0/schedutil/up_rate_limit_us
echo 80000 > /sys/devices/system/cpu/cpufreq/policy0/schedutil/down_rate_limit_us
echo 1 > /sys/devices/system/cpu/cpufreq/policy0/schedutil/iowait_boost_enable

echo "schedutil" > /sys/devices/system/cpu/cpu4/cpufreq/scaling_governor
echo 0 > /sys/devices/system/cpu/cpufreq/policy4/schedutil/up_rate_limit_us
echo 40000 > /sys/devices/system/cpu/cpufreq/policy4/schedutil/down_rate_limit_us
echo 1 > /sys/devices/system/cpu/cpufreq/policy4/schedutil/iowait_boost_enable

echo "schedutil" > /sys/devices/system/cpu/cpu7/cpufreq/scaling_governor
echo 0 > /sys/devices/system/cpu/cpufreq/policy7/schedutil/up_rate_limit_us
echo 20000 > /sys/devices/system/cpu/cpufreq/policy7/schedutil/down_rate_limit_us
echo 1 > /sys/devices/system/cpu/cpufreq/policy7/schedutil/iowait_boost_enable

echo 2-3 > /dev/cpuset/audio-app/cpus
echo 2-3 > /dev/cpuset/background/cpus
echo 0-3 > /dev/cpuset/restricted/cpus
echo 0-3 > /dev/cpuset/system-background/cpus
echo 0-3 > /dev/cpuset/display/cpus
echo 0-6 > /dev/cpuset/foreground/cpus
echo 0-7 > /dev/cpuset/camera-daemon/cpus
echo 0-7 > /dev/cpuset/top-app/cpus

echo 2016000 > /sys/devices/system/cpu/cpu4/cpufreq/scaling_max_freq
echo 2131200 > /sys/devices/system/cpu/cpu7/cpufreq/scaling_max_freq

echo 1 > /sys/module/pikachu_boost/parameters/is_scib_enabled
echo 1 > /sys/module/pikachu_boost/parameters/is_dynamic_eas_enabled
echo 128 > /sys/module/pikachu_boost/parameters/input_boost_duration
echo 1478400 > /sys/module/pikachu_boost/parameters/input_boost_freq_little
echo 1056000 > /sys/module/pikachu_boost/parameters/input_boost_freq_big
echo 1785600 > /sys/module/pikachu_boost/parameters/max_boost_freq_little
echo 1056000 > /sys/module/pikachu_boost/parameters/max_boost_freq_big
echo 1171200 > /sys/module/pikachu_boost/parameters/max_boost_freq_prime

echo 3879 > /sys/devices/platform/soc/soc:qcom,cpu-llcc-ddr-bw/devfreq/soc:qcom,cpu-llcc-ddr-bw/min_freq
echo 3879 > /sys/devices/platform/soc/soc:qcom,cpu-llcc-ddr-bw/devfreq/soc:qcom,cpu-llcc-ddr-bw/max_freq
echo 3879 > /sys/class/devfreq/soc:qcom,cpu0-llcc-ddr-lat/min_freq
echo 3879 > /sys/class/devfreq/soc:qcom,cpu4-llcc-ddr-lat/min_freq
echo 1612800000 > /sys/class/devfreq/soc:qcom,cpu0-cpu-l3-lat/min_freq
echo 1612800000 > /sys/class/devfreq/soc:qcom,cpu4-cpu-l3-lat/min_freq
echo 1612800000 > /sys/class/devfreq/soc:qcom,cpu7-cpu-l3-lat/min_freq

for i in /sys/block/*/queue; do
  echo 0 > $i/iostats;
done;

echo 5 > /proc/sys/vm/dirty_background_ratio
echo 3000 > /proc/sys/vm/dirty_expire_centisecs
echo 0 > /proc/sys/vm/page-cluster

echo 2000 > /dev/blkio/blkio.group_idle
echo 0 > /dev/blkio/background/blkio.group_idle
echo 1000 > /dev/blkio/blkio.weight
echo 10 > /dev/blkio/background/blkio.weight

echo 1 > /dev/stune/foreground/schedtune.prefer_idle
echo 1 > /dev/stune/top-app/schedtune.prefer_idle
echo 3 > /dev/stune/top-app/schedtune.boost

lock_val "1" /sys/block/sda/queue/iosched/back_seek_penalty
lock_val "0" /sys/block/sda/queue/iosched/slice_idle
lock_val "16" /sys/block/sda/queue/iosched/quantum

lock_val "0" /sys/class/kgsl/kgsl-3d0/force_no_nap
lock_val "1" /sys/class/kgsl/kgsl-3d0/bus_split
lock_val "0" /sys/class/kgsl/kgsl-3d0/force_bus_on
lock_val "0" /sys/class/kgsl/kgsl-3d0/force_clk_on

# yuhan@maintainer, 2019/12/21 Hack to westwood
# TODO: westwood and bbr plan
# Sometimes bbr added a lot of network delay, westwood more stable
sysctl -w net.ipv4.tcp_congestion_control=westwood

lock_val "1" /sys/block/sda/queue/iosched/back_seek_penalty
lock_val "0" /sys/block/sda/queue/iosched/slice_idle
lock_val "16" /sys/block/sda/queue/iosched/quantum
lock_val "128" /sys/block/sda/queue/read_ahead_kb

lock_val "19200,25600,51200,76800,128000,179200" /sys/module/lowmemorykiller/parameters/minfree
lock_val "0,200,920,930,940,950" /sys/module/lowmemorykiller/parameters/adj
lock_val "48" /sys/module/lowmemorykiller/parameters/cost

stop vendor.msm_irqbalance
start vendor.msm_irqbalance
