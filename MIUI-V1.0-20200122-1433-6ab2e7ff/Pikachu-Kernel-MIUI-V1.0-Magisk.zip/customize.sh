mkdir -p $MODDIR/system/vendor/etc/init/hw/
cp -f /system/vendor/etc/init/hw/init.oem.rc $MODDIR/system/vendor/etc/init/hw/init.oem.rc
cp -f /system/vendor/etc/init/hw/init.qcom.rc $MODDIR/system/vendor/etc/init/hw/init.qcom.rc
cp -f /system/vendor/etc/init/hw/init.oem.debug.rc $MODDIR/system/vendor/etc/init/hw/init.oem.debug.rc
sed -i '/houston/d' $MODDIR/system/vendor/etc/init/hw/init.oem.rc
sed -i '/cc_ctl/d' $MODDIR/system/vendor/etc/init/hw/init.oem.rc
sed -i '/opchain/d' $MODDIR/system/vendor/etc/init/hw/init.oem.rc
sed -i '/ht_ctl/d' $MODDIR/system/vendor/etc/init/hw/init.oem.rc
sed -i '/core_ctl/d' $MODDIR/system/vendor/etc/init/hw/init.oem.rc
sed -i '/service bugreport/,/oneshot/d' $MODDIR/system/vendor/etc/init/hw/init.oem.rc
sed -i '/service OPDiagdataCopy/,/start OPDiagdataCopy/d' $MODDIR/system/vendor/etc/init/hw/init.oem.rc
sed -i '/service opdiagnose/,/group system/d' $MODDIR/system/vendor/etc/init/hw/init.oem.rc
sed -i '/OPDiagnose/d' $MODDIR/system/vendor/etc/init/hw/init.oem.rc
sed -i '/fragment_monitor/d' $MODDIR/system/vendor/etc/init/hw/init.qcom.rc
sed -i '/service oemlogkit/,/socket oemlogkit/d' $MODDIR/system/vendor/etc/init/hw/init.oem.debug.rc
sed -i '/service charger_logkit/,/seclabel u:r:charger_log:s0/d' $MODDIR/system/vendor/etc/init/hw/init.oem.debug.rc

set_perm $MODPATH/system/bin/pikachu 0 2000 0755 0755
