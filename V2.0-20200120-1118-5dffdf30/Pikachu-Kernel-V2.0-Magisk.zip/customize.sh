REPLACE="
/system/app/LogKitSdService
/system/app/OEMLogKit
/system/app/OPBugReportLite
/system/app/OPCommonLogTool
/system/app/OPIntelliService
/system/app/OPTelephonyDiagnoseManager
/system/priv-app/Houston
/system/priv-app/OPAppCategoryProvider
/system/priv-app/OPDeviceManager
/system/priv-app/OPDeviceManagerProvider
"

feature_list="
OP_FEATURE_AI_BOOST_PACKAGE
OP_FEATURE_APP_PRELOAD
OP_FEATURE_BUGREPORT
OP_FEATURE_OHPD
OP_FEATURE_OPDIAGNOSE
OP_FEATURE_OPSLA
OP_FEATURE_PRELOAD_APP_TO_DATA
OP_FEATURE_SMART_BOOST
"

mkdir -p $MODDIR/system/etc/
cp -f /system/etc/feature_list $MODDIR/system/etc/feature_list
 for i in $feature_list ; do
   if [ "$(grep $i $MODDIR/system/etc/feature_list)" != "" ]; then
     sed -i -e "/$i/{n;d}" -e "$!N;/\n.*$i/!P;D" $MODDIR/system/etc/feature_list
     sed -i "/$i/d" $MODDIR/system/etc/feature_list
   fi
done

mkdir -p $MODDIR/system/vendor/etc/init/hw/
cp -f /system/vendor/etc/init/hw/init.oem.rc $MODDIR/system/vendor/etc/init/hw/init.oem.rc
cp -f /system/vendor/etc/init/hw/init.qcom.rc $MODDIR/system/vendor/etc/init/hw/init.qcom.rc
cp -f /system/vendor/etc/init/hw/init.oem.debug.rc $MODDIR/system/vendor/etc/init/hw/init.oem.debug.rc
sed -i '/houston/d' $MODDIR/system/vendor/etc/init/hw/init.oem.rc
sed -i '/cc_ctl/d' $MODDIR/system/vendor/etc/init/hw/init.oem.rc
sed -i '/opchain/d' $MODDIR/system/vendor/etc/init/hw/init.oem.rc
sed -i '/ht_ctl/d' $MODDIR/system/vendor/etc/init/hw/init.oem.rc
sed -i '/core_ctl/d' $MODDIR/system/vendor/etc/init/hw/init.oem.rc
sed -i '/service bugreport/,/oneshot/d' $MODDIR/system/vendor/etc/init/hw/init.oem.rc
sed -i '/service OPDiagdataCopy/,/start OPDiagdataCopy/d' $MODDIR/system/vendor/etc/init/hw/init.oem.rc
sed -i '/service opdiagnose/,/group system/d' $MODDIR/system/vendor/etc/init/hw/init.oem.rc
sed -i '/OPDiagnose/d' $MODDIR/system/vendor/etc/init/hw/init.oem.rc
sed -i '/fragment_monitor/d' $MODDIR/system/vendor/etc/init/hw/init.qcom.rc
sed -i '/service oemlogkit/,/socket oemlogkit/d' $MODDIR/system/vendor/etc/init/hw/init.oem.debug.rc
sed -i '/service charger_logkit/,/seclabel u:r:charger_log:s0/d' $MODDIR/system/vendor/etc/init/hw/init.oem.debug.rc

set_perm $MODPATH/system/bin/pikachu 0 2000 0755 0755
