#!/system/bin/sh
# Do NOT assume where your module will be located.
# ALWAYS use $MODDIR if you need to know where this script
# and module is placed.
# This will make sure your module will still work
# if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in late_start service mode
sleep 30
## Start Hacking Kernel Profiles
echo 500 > /sys/devices/system/cpu/cpufreq/policy0/schedutil/up_rate_limit_us
echo 20000 > /sys/devices/system/cpu/cpufreq/policy0/schedutil/down_rate_limit_us

echo 500 > /sys/devices/system/cpu/cpufreq/policy4/schedutil/up_rate_limit_us
echo 20000 > /sys/devices/system/cpu/cpufreq/policy4/schedutil/down_rate_limit_us

echo 500 > /sys/devices/system/cpu/cpufreq/policy7/schedutil/up_rate_limit_us
echo 20000 > /sys/devices/system/cpu/cpufreq/policy7/schedutil/down_rate_limit_us

echo 585000000 > /sys/class/kgsl/kgsl-3d0/devfreq/max_freq

# yuhan@maintainer, 2019/11/23 modify because we are using cpusets assist and seted on kernel
#echo 0-3 > /dev/cpuset/restricted/cpus
#echo 0-3 > /dev/cpuset/audio-app/cpus
#echo 0-7 > /dev/cpuset/camera-daemon/cpus
#echo 0-7 > /dev/cpuset/top-app/cpus
#echo 0-3,5-6 > /dev/cpuset/foreground/cpus
#echo 0-1 > /dev/cpuset/background/cpus
#echo 0-3 > /dev/cpuset/system-background/cpus

for i in /sys/block/*/queue; do
  echo 0 > $i/iostats;
done;

echo 0 > /dev/blkio/blkio.group_idle
echo 0 > /dev/blkio/background/blkio.group_idle

echo 1000 > /dev/blkio/blkio.weight
echo 10 > /dev/blkio/background/blkio.weight

echo 1 > /dev/stune/foreground/schedtune.prefer_idle
echo 1 > /dev/stune/top-app/schedtune.prefer_idle
echo 1 > /dev/stune/top-app/schedtune.boost

sysctl -w net.ipv4.tcp_congestion_control=westwood

echo 1382400 > /sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq
echo 1056000 > /sys/devices/system/cpu/cpu4/cpufreq/scaling_min_freq
echo 2323200 > /sys/devices/system/cpu/cpu4/cpufreq/scaling_max_freq
echo 1171200 > /sys/devices/system/cpu/cpu7/cpufreq/scaling_min_freq
echo 2649600 > /sys/devices/system/cpu/cpu7/cpufreq/scaling_max_freq

stop vendor.msm_irqbalance
start vendor.msm_irqbalance

## Check results
# Remove older check results
rm -rf /data/pikachu_profile.log

yuhan_check(){
now_profile=$(cat $2)
set_profile=$(echo $1)
if [[ "$now_profile" == "$set_profile" ]] ; then
    echo "[Sucess] Sucessfully seted $2 to $1" >> /data/pikachu_profile.log
else
    echo "[Failure] Failed seted $2 to $1, now it is $now_profile" >> /data/pikachu_profile.log
fi
}

echo "[INFO] Pikachu Kernel Module Profile Initer" >> /data/pikachu_profile.log
echo "[INFO] Author: Jiuyumengzhou <yuhan@rsyhan.me>" >> /data/pikachu_profile.log

yuhan_check 500 /sys/devices/system/cpu/cpufreq/policy0/schedutil/up_rate_limit_us
yuhan_check 20000 /sys/devices/system/cpu/cpufreq/policy0/schedutil/down_rate_limit_us
yuhan_check 500 /sys/devices/system/cpu/cpufreq/policy4/schedutil/up_rate_limit_us
yuhan_check 20000 /sys/devices/system/cpu/cpufreq/policy4/schedutil/down_rate_limit_us
yuhan_check 500 /sys/devices/system/cpu/cpufreq/policy7/schedutil/up_rate_limit_us
yuhan_check 20000 /sys/devices/system/cpu/cpufreq/policy7/schedutil/down_rate_limit_us
yuhan_check 585000000 /sys/class/kgsl/kgsl-3d0/devfreq/max_freq

# yuhan@maintainer, 2019/11/23 modify because we are using cpusets assist and seted on kernel
#yuhan_check 0-3 /dev/cpuset/restricted/cpus
#yuhan_check 0-3 /dev/cpuset/audio-app/cpus
#yuhan_check 0-7 /dev/cpuset/camera-daemon/cpus
#yuhan_check 0-7 /dev/cpuset/top-app/cpus
#yuhan_check 0-3,5-6 /dev/cpuset/foreground/cpus
#yuhan_check 0-1 /dev/cpuset/background/cpus
#yuhan_check 0-3 /dev/cpuset/system-background/cpus

for i in /sys/block/*/queue; do
  yuhan_check 0 $i/iostats;
done;
yuhan_check 0 /dev/blkio/blkio.group_idle
yuhan_check 0 /dev/blkio/background/blkio.group_idle
yuhan_check 1000 /dev/blkio/blkio.weight
yuhan_check 10 /dev/blkio/background/blkio.weight
yuhan_check 1 /dev/stune/foreground/schedtune.prefer_idle
yuhan_check 1 /dev/stune/top-app/schedtune.prefer_idle
yuhan_check 1 /dev/stune/top-app/schedtune.boost
yuhan_check 1382400 /sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq
yuhan_check 1056000 /sys/devices/system/cpu/cpu4/cpufreq/scaling_min_freq
yuhan_check 2323200 /sys/devices/system/cpu/cpu4/cpufreq/scaling_max_freq
yuhan_check 1171200 /sys/devices/system/cpu/cpu7/cpufreq/scaling_min_freq
yuhan_check 2649600 /sys/devices/system/cpu/cpu7/cpufreq/scaling_max_freq

# yuhan@maintainer, 2019/11/23 modify for checking tcp congestion
yuhan_check westwood /proc/sys/net/ipv4/tcp_congestion_control

stop oneplus_brain_service

op_brain_status=$(getprop init.svc.oneplus_brain_service)
status_stopped
if [[ "$op_brain_status" == "$status_stopped" ]] ; then
    echo "[Sucess] Sucessfully stopped OnePlus AI Brain Service" >> /data/pikachu_profile.log
else
    echo "[Failure] Failed to stop OnePlus AI Brain Service" >> /data/pikachu_profile.log
fi

echo "[INFO] Pikachu Kernel Profile Applied" >> /data/pikachu_profile.log
echo "[INFO] Author: Jiyumengzhou <yuhan@rsyhan.me>" >> /data/pikachu_profile.log
